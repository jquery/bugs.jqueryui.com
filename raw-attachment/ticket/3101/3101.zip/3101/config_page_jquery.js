function init_jquery()
{

        $("#TrxOptSlider").slider(
        {
            steps: 3,
            min: 0,
            max: 3,
            change: function(e, ui)
            {
                var lValue = $('#TrxOptSlider').slider('value', 0) + 1;
                // set the value into the hidden field.
                $("#TrxOptimizationLevelValue").val( lValue );
            }
		} );

        // Set the innitial value
        if ( $("#TrxOptimizationLevelValue").val() != "" )
        {
            var lValue = parseInt($("#TrxOptimizationLevelValue").val(),10);
            //alert(lValue);
           setTimeout(function(){ $("#TrxOptSlider").slider("moveTo", lValue)} ,10);
        }

    
}


